Sliced Fruits Pack  
by ssugmi  
https://ssugmi.itch.io/sliced-fruits

License & Usage

Free to use in both commercial and non-commercial projects

Modifications are allowed

Reselling, redistributing, or repackaging (even modified) is prohibited

Credit is appreciated but not required

Thank you for using this asset pack!

Feel free to check out more at: https://ssugmi.itch.io